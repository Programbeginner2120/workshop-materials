from functools import reduce

def challenges():
    my_list = [1,2,3,4,5]
    """Challenge #1: Get the third element of my_list 
    using get_head and get_tail"""

    # put your code here

    """Challenge #2: Get the second to last element of
    my_list"""

    # put your code here

    """Challenge #3: Create a lambda function that adds
    three numbers togehter"""

    # put your code here



    """map(), filter() and reduce()"""

    my_list = [1,2,3,4,5]

    """Map Challenge #1: Use map to multiply each element by 2"""
    # put code here

    """Map Challenge #2: Use map to raise each element to the third power"""
    # put code here

    """Map Challenge #3: Use map to divide each element by itself"""
    # put code here
    
    fruit_list = ["Apple", "Banana", "Pear", "Watermelon", "Cranberry"]

    """Filter Challenge #1: Use filter to take out all values in fruit_list length < 5"""
    # put code here

    """Filter Challenge #2: Use filter to remove all values in fruit_list with even length"""
    # put code here

    """Filter Challenge #3: Use filter to remove all values in fruit_list that start with 'C'"""
    # put code here

    """Reduce Challenge #1: Use reduce to subtract all elements in my_list"""
    # put code here
    

    """Reduce Challenge #2: Use reduce to multiply all elements in my_list"""
    # put code here
    

    """Reduce Challenge #3: Use reduce to add all of the elements squared in the list"""
    # put code here

def main():
    challenges()

if __name__ == "__main__":
    main()